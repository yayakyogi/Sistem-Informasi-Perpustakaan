<?php 
  include 'koneksi.php';
  include 'template.php';
  include 'tabel.php';
  include 'view_superadmin.php';

  $page = GET('pages','dashboard');
  $view = GET('view','index');
?>